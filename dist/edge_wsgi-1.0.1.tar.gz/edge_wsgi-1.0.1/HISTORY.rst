History
-------

1.0.0 (2019-10-11)
------------------

* First release on, working basic integration for WSGI apps on lambda@edge

1.0.1 (2025-01-24)
------------------

* Adapt with new build system
